# 05 Solution (bento grid, five cards, varied sizes)

## Heading (two lines)
Five jobs.
One chat.

## Subtitle (one line)
It all happens in the same conversation, so you never switch apps.

## Cards
1. Ask anything (largest card)
   Questions, essays, code, ideas. Zox answers short, and tells you straight when it's unsure.

2. Search the web
   Doesn't know something? Zox looks it up instead of guessing.

3. Read a PDF
   Send the file. Get the point in seconds.

4. Watch a video
   Paste a YouTube link. Get the summary, not the 90 minutes.

5. See a photo
   Snap a handwritten problem or a diagram. Zox reads it and explains it.

Each card gets one small illustration. No icon-in-a-circle headers.
