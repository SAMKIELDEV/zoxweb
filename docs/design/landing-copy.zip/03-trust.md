# 03 Trust

One number, one line. No logo wall, no testimonials.

Line: 467+ people already text Zox.
Small line: Made by SAMKIEL in Ile-Ife, Nigeria.

Note: confirm what 467+ measures and keep the label honest. See README.
