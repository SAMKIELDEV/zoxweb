# 08 Call to action

Same background as the hero. Centred. Two lines, one button, and the phone composer repeated.

## Heading (two lines)
Stop switching apps.
Just text Zox.

## Button
Open WhatsApp

## Composer placeholder
Ask Zox anything
