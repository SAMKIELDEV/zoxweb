# 09 Footer

Logo and tagline on a dark card, four plain link columns, and a large faded wordmark at the bottom.

## Tagline
Zox gets to the point.

## Columns
Product: How it works | Pricing | Blog
Account: Sign in | Dashboard
Company: Contact | SAMKIEL
Legal: Terms | Privacy | Refunds | Acceptable use

## Bottom line
© 2026 SAMKIEL Technologies Limited. RC 9540139.

Social icons go under the logo. Add only the accounts that actually exist.
